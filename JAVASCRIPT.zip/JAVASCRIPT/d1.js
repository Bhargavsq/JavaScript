//document.write("Hello Bhargo this is in js file");
// let val = window.confirm("OK or Cancel");
// if(val===true){
//     console.log("OK");
// }else{
//     console.log("Cancel");
// }

// let a= document.getElementById("p1");
// console.dir(a);
// let b = document.getElementsByClassName("p")
// console.dir(b);
// let c = document.getElementsByTagName("p");
// console.log(c);

// let firstElement = document.querySelector("p");
// console.dir(firstElement);
// let Element = document.querySelectorAll("p");
// console.dir(Element);

//dom properties
// let div = document.querySelector("div");
// console.dir(div);
// div.tagName;
// div.innerText;
// div.innerHTML;
// div.textContent;

// let he = document.querySelector("h2");
// console.dir(he.innerText);
// he.innerText= he.innerText +" from apna college student";

let div = document.querySelector(".box");


//dom tree child <---HW--->
//  3 type text comment Element node
//fistchild lastchild childeren

