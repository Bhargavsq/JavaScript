//pro 1
// document.write("YOOOO");
// let btn = document.createElement("button");

// btn.style.backgroundColor="red";
// btn.style.color="white";

// document.querySelector("body").prepend(btn);
// btn.innerText="Click me";

//pro 2 add class using js
let para= document.querySelector("p");
para.classList.add("newclass");