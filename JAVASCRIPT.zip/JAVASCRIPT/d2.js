// let div = document.querySelector("div");
// div.style.backgroundColor ="pink";
// div.style.color="blue";

// let newbtn = document.createElement("button");
// newbtn.innerText="Click!";
// console.log(newbtn);

// let div = document.querySelector("div");
// div.prepend(newbtn);//in div start
// div.append(newbtn);//end
// div.before(newbtn);//out of div start
// div.after(newbtn);end

// add button at last
let newbtn = document.createElement("button");
newbtn.innerText="Click!";
console.log(newbtn);
let p = document.querySelector("p");
p.after(newbtn);

//add head
let head= document.createElement("h1");
head.innerHTML="<i>Hello bhargo<i>";
document.querySelector("body").prepend(head);

//remove element
// let para = document.querySelector("p");
// para.remove();
// head.remove();

// appendchild or removechild
