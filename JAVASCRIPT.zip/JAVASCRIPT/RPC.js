let userScore = 0;
let computerScore = 0;

const choices = document.querySelectorAll(".choice");
const msg = document.querySelector("#msg");
const userScorepara = document.querySelector("#user-score");
const computerScorepara = document.querySelector("#computer-score");


const gencomputerchoice = () =>{
    const options = ["Rock","Paper","Scissors"];
    const randIdx = Math.floor(Math.random()*3);
    return options[randIdx];
}

const drewgame = ()=>{
    console.log("Game was drew");
    msg.innerText="Game was drew!!!";
    msg.style.backgroundColor = "grey";
}

const showWinner = (userWin,userchoice,computerchoice)=>{
    if(userWin){
        userScore++;
        userScorepara.innerText = userScore;
        console.log("You Win!!!");
        msg.innerText=`You Win!!! Your ${userchoice} beats ${computerchoice}`;
        msg.style.backgroundColor = "green";
    }else{
        computerScore++;
        computerScorepara.innerText = computerScore;
        console.log("Computer Win!!!");
        msg.innerText=`Computer Win!!! ${computerchoice} beats Your ${userchoice}`;
        msg.style.backgroundColor = "red";
    }
}

const playgame=(userchoice)=>{
    console.log("User choice = ",userchoice);
    const computerchoice = gencomputerchoice();
    console.log("com choice = ",computerchoice);

    if(userchoice===computerchoice){
        //drew
        drewgame();
    }else{
        let userWin =true;
        if(userchoice === "rock"){
            userWin = computerchoice === "Paper" ? false : true;
        }else if(userchoice === "Paper"){
            userWin = computerchoice === "Scissors" ? false : true;
        }else{
            userWin = computerchoice === "Rock" ? false : true;
        }
        showWinner(userWin,userchoice,computerchoice);
    }
}
choices.forEach((choice)=>{
    choice.addEventListener("click",()=>{
        const userchoice = choice.getAttribute("id");
        playgame(userchoice);
       
    });
})