//crash chrome
// for(let i=0;i>=0;i++){
//     console.log(i);
// }

//tamplate literals | string interpolation
// let obj = {
//     name:"Bhargav",
//     id:"23Msit015"
// }
// let pr = `name is ${obj.name} and id is ${obj.id}`;
// console.log(pr);

// let fname=prompt("enter user name : ")
// let newName="@"+ fname +fname.length;
// console.log(newName);

//string immutable
//array mutable
// let arr = ["Bhargav","patel","Bhargo"];
// console.log(arr.length);
// console.log(typeof(arr));
// //simple for
// for(let i=0;i<arr.length;i++){
//     console.log(arr[i]);
// }
// //for of
// for(let nm of arr){
//     console.log(nm);
// }

// let marks = [85,97,44,37,76,60];
// let sum=0;
// for(let nm of marks){
//     sum = sum + nm;
// }
// let res=sum/marks.length;
// console.log(res);

// let items = [250,645,300,900,50];
// let i=0;
// for(let nm of items){
//     let offer  = nm/10;
//     items[i]=items[i]-offer;
//     console.log(`val after offers = ${items[i]}`);
//     i++;
// }

// let companies = ["Bloomberg","Microsoft","Uber","Google","IBM","Netflix"]
// console.log(companies);
// let remov = companies.shift();
// console.log(remov);
// console.log(companies);
// let repla = companies.splice(2,1,"ola")
// console.log(companies);
// let add = companies.push("Amazon");
// console.log(companies);


// function countVowals(str){
//     let count = 0;
//     for(const char of str){
//         if(char === "a" ||
//             char === "e"||
//             char === "i"||
//             char === "o"||
//             char === "u"
//             ){
//                 count++;
//             }
//     }document.write(count);
// }
// countVowals("aeiou");

// const countVowals = (str)=>{
//     let count=0;
//     for(const char of str){
//         if(char === "a" ||
//         char === "e"||
//         char === "i"||
//         char === "o"||
//         char === "u"){
//             count++;
//         }
//     }return count;
// };

//foreach loop
// array.forEach(element => {
// });
// let array=[12,13,14,141,51];
// array.forEach(function printVal(val) {
//     console.log(val);
// });
// let array=[12,13,14,141,51];
// array.forEach((val) => {
//     console.log(val);
// });
//higher order function or higher order method
// let array =["bhargav","patel","gojo","jadu","lalu"] 
// array.forEach((val,idx,arr) => {
//     console.log(val.toUpperCase(),idx,arr);
// });

// let num=[2,3,4,5,6];
// num.forEach((num)=>{
//     console.log(num*num);
// });

// Map
// create a new array with the results of some opertaion
// the value its callback returns are used to form new array
//main used of map is new array
// let num=[2,3,4,5,6];
// num.map((val)=>{
//     console.log(val);
// });

// let arr=[1,2,3,4];
// const narr = arr.reduce((pre,curr)=>{
//     return pre+curr;
// });
// console.log(narr);

// let arr=[1,2,3,4,23,2,32];
// const narr = arr.reduce((pre,curr)=>{
//     return pre>curr?pre:curr;
// });
// console.log(narr);

// filter marks of student
// let marks=[87,68,89,99,81,91];
// let topper = marks.filter((val)=>{
//     return val>90;
// });
// console.log(topper);

// let n = prompt("Enter num :")
// let arr=[];
// for(let i=1;i<=n;i++){
//     arr[i-1] =i;
// }
// console.log(arr);
// // reduce method to sum of all val
// let redu = arr.reduce((pre,cur)=>{
//     return pre+cur;
// })
// console.log("sum :"+redu);
// //reduce method to cal product of all num in arr || factorial
// let facto = arr.reduce((pre,cur)=>{
//     return pre*cur;
// })
// console.log("factorial :"+facto);